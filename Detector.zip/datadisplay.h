﻿#ifndef DATADISPLAY_H
#define DATADISPLAY_H

#include <QWidget>
#include <Qwt/qwt_thermo.h>
#include <QLabel>
#include <QComboBox>
#include <QGridLayout>
#include <QTcpSocket>

class DataDisplay : public QWidget
{
public:
    DataDisplay(QWidget *parent = nullptr);
    ~DataDisplay();
private:
    QwtThermo *thermoMetre;
    QLabel *thermoLabel;
    QLabel *thermoLabelNum;
    QLabel *nodeSelectionLabel;
    QComboBox *nodeSelection;
    QLabel *accelerationX;
    QLabel *accelerationXNum;
    QLabel *accelerationY;
    QLabel *accelerationYNum;
    QLabel *accelerationZ;
    QLabel *accelerationZNum;
    QLabel *gyroscopeX;
    QLabel *gyroscopeXNum;
    QLabel *gyroscopeY;
    QLabel *gyroscopeYNum;
    QLabel *gyroscopeZ;
    QLabel *gyroscopeZNum;
    QLabel *rollAngel;
    QLabel *rollAngelNum;
    QLabel *pitchAngel;
    QLabel *pitchAngelNum;
    QLabel *driftAngel;
    QLabel *driftAngelNum;
    QGridLayout *dataDisplayLayout;
public slots:
    void currentSocketChanged(QTcpSocket *currentSocket);
    void getData(int socketDescriptor, QString data);
};

#endif // DATADISPLAY_H
